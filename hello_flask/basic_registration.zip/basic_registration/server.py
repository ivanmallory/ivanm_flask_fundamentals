from flask import Flask, render_template, request, redirect, session, flash
from mysqlconnection import connectToMySQL

app = Flask(__name__)
app.secret_key = "Welcome to the thunder dome"

@app.route("/")
def home():
    mysql = connectToMySQL("registration")
    users = mysql.query_db("SELECT * FROM users;")
    print(users)
    return render_template("index.html", all_users = users)

@app.route("/create_user", methods=['POST'])
def create_user():
    is_valid = True
    if len(request.form['fname']) < 1:
        is_valid = False
        flash("Please enter a first name")
    if len(request.form['lname']) < 1:
        is_valid = False
        flash("Please enter a last name")
    if len(request.form['pass']) < 5:
        is_valid = False
        flash("Password Must Be At Least 5 Characters")
    if request.form['cpass'] != request.form ['pass']:
        is_valid = False
        flash("Incorrect Password")
    if is_valid:
        mysql = connectToMySQL("registration")
        query = "INSERT into users(first_name, last_name, password, created_at, updated_at) VALUES (%(fname)s, %(lname)s, %(pass)s, NOW(), NOW());"

        data = {
            "fname": request.form['fname'],
            "lname": request.form['lname'],
            "pass": request.form['pass'],
        }
        mysql.query_db(query, data)
        flash("Successfully added!")
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)